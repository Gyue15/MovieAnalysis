package cluster;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.clustering.GaussianMixture;
import org.apache.spark.mllib.clustering.GaussianMixtureModel;
import org.apache.spark.mllib.linalg.Vector;

public class GaussianMixtureCluster {

    public static void train(JavaRDD<Vector> trainingData, JavaSparkContext jsc, int numCluster) {
        // Cluster the data into two classes using GaussianMixture
        GaussianMixtureModel gmm = new GaussianMixture().setK(numCluster).run(trainingData.rdd());

        // Save and load GaussianMixtureModel
        gmm.save(jsc.sc(), "target/org/apache/spark/JavaGaussianMixtureExample/GaussianMixtureModel");
        GaussianMixtureModel sameModel = GaussianMixtureModel.load(jsc.sc(), "target/org.apache.spark" +
                ".JavaGaussianMixtureExample/GaussianMixtureModel");

        // Output the parameters of the mixture model
        for (int j = 0; j < gmm.k(); j++) {
            System.out.printf("weight=%f\nmu=%s\nsigma=\n%s\n", gmm.weights()[j], gmm.gaussians()[j].mu(),
                    gmm.gaussians()[j].sigma());
        }
    }
}
