import cluster.BisectingKMeansCluster;
import cluster.KMeansCluster;
import cluster.LDACluster;
import com.alibaba.fastjson.JSONObject;
import com.mongodb.spark.MongoSpark;
import com.mongodb.spark.config.WriteConfig;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.regression.LabeledPoint;
import org.apache.spark.sql.SparkSession;
import org.bson.Document;
import regression.LinearRegression;

import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        SparkSession sparkSession = SparkSession.builder()
                .appName("StreamingProcess")
                .config("spark.mongodb.output.uri", "mongodb://localhost:27017/")
                .config("spark.mongodb.output.database", "film")
                .config("spark.mongodb.output.collection", "testCollection")
                .master("local")
                .getOrCreate();
        JavaSparkContext jsc = new JavaSparkContext(sparkSession.sparkContext());
        Logger.getLogger("org").setLevel(Level.ERROR);
        String modelPath = "model/BoxLinearRegression";
        JavaRDD<LabeledPoint> trainData = DataLoader.loadLabeledPoint(jsc, "data/box_train_data.txt");
        LinearRegression.train(trainData, jsc, 2000000000, 1, modelPath);
//        GBTRegression.train(trainData, jsc, 300, 10, null);
        JavaRDD<LabeledPoint> testData = DataLoader.loadLabeledPoint(jsc, "data/box_test_data.txt");
        LinearRegression.test(testData, jsc, modelPath);
//        GBTRegression.test(testData, jsc, null;
//        JavaRDD<Vector> clusterTrainData = DataLoader.loadVector(jsc, "data/cluster_train_data.txt");
//        JavaPairRDD<Long, Vector> clusterTrainData = DataLoader.loadIndexVector(jsc,
//                "data/cluster_train_data_small" + ".txt");
//        clusterTrainData.cache();
//        LDACluster.train(clusterTrainData, jsc, 50);
//        KMeansCluster.train(clusterTrainData, jsc, 50, 100000000);
//        GaussianMixtureCluster.train(clusterTrainData, jsc, 10);
//        BisectingKMeansCluster.train(clusterTrainData, jsc, 50);
//        JavaRDD<Vector> clusterPredictData = DataLoader.loadVector(jsc, "data/regression_test_data_small.txt");
//        JavaPairRDD<Long, Vector> clusterPredictData = DataLoader.loadIndexVector(jsc,
//                "data/regression_test_data_small.txt");
//        JavaRDD<Integer> test = KMeansCluster.predict(jsc, clusterPredictData);

//        test.rdd().saveAsTextFile("data/cluster_res");
//        JavaRDD<Integer> train = BisectingKMeansCluster.predict(jsc, clusterTrainData);
//        train.rdd().saveAsTextFile("data/cluster_res");


//        Map<String, String> writeOverrides = new HashMap<>();
//        writeOverrides.put("collection", "train_res");
//        writeOverrides.put("writeConcern.w", "majority");
//        WriteConfig writeConfig = WriteConfig.create(jsc).withOptions(writeOverrides);
//
//        MongoSpark.save(train.map(i -> {
//            JSONObject jsonObject = new JSONObject();
//            jsonObject.put("res", i);
//            return Document.parse(jsonObject.toJSONString());
//        }), writeConfig);

    }
}
